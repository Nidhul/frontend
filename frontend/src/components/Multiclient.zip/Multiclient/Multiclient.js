
import './Multiclient.css'
import axios from 'axios';
import React, { useEffect, useState, useRef } from "react";
import Swal from 'sweetalert2';

function Multiclient() {

  const [positions, setPositions] = useState([]);
  const [filteredPositions, setFilteredPositions] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [itemsPerPage, setItemsPerPage] = useState(10); // Default to 10 items per page
  const [currentPage, setCurrentPage] = useState(1); // For pagination
  const [currentEditData, setCurrentEditData] = useState(null);
  const buttonRef = useRef(null);
  const [token, settoken] = useState('')
  const [broker, setBroker] = useState("");
  const [brokerid, setBrokerid] = useState("");
  const [twofa, setTwofa] = useState("");
  const [mpin, setMpin] = useState("");
  const [apikey, setApikey] = useState("");
  const [apisecret, setApiSecret] = useState("");
  const [phonenumber, setPhonenumber] = useState("");
  const [lotsize, setlotsize] = useState("");
  const [user_name, setuser_name] = useState("");
  const [user_id, setuser_id] = useState("")

  const [formValues, setFormValues] = useState({
    transition_type: "",
    product_type: "",
    quantity: "",
    order_type: "",

  });



  useEffect(() => {
    const access = localStorage.getItem("accessToken");
    settoken(localStorage.getItem("accessToken"));
    if (access) {
      fetchuserDetails(access);
    }

  }, []);




  const fetchuserDetails = async (token) => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL_INTERACTIVE}user-broker-details/filterbyuser/`, {
        headers: {
          Authorization: `Token ${token}`,
        },
      });

      console.log(response.data); // Log the response to check its structure
      setPositions(response.data.data); // Assuming `data` is an array
      setFilteredPositions(response.data.data); // Initialize with all data
    } catch (error) {
      console.log('Error fetching positions', error);
    }
  };





  const handleSearch = (event) => {
    const searchValue = event.target.value.toLowerCase();
    setSearchTerm(searchValue);

    // Check if positions is an array before filtering
    if (Array.isArray(positions)) {
      const filteredData = positions.filter((position) =>
        position.nick_name.toLowerCase().includes(searchValue) // Or the correct field
      );
      setFilteredPositions(filteredData);
    } else {
      console.error('Positions is not an array:', positions);
    }
    setCurrentPage(1); // Reset to first page after filtering
  };


  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredPositions.slice(
    indexOfFirstItem,
    indexOfLastItem
  );

  const totalPages = Math.ceil(filteredPositions.length / itemsPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage((prevPage) => prevPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);
    }
  };

  const handleRowsChange = (event) => {
    setItemsPerPage(Number(event.target.value));
    setCurrentPage(1); // Reset to first page when the rows per page change
  };

  // Function to handle the Modify button click
  const handleModify = (position) => {
    console.log(position)
    setuser_id(position.id)
    if (position.id) {
      buttonRef.current.click();
    }
    // Programmatically click the hidden button to open modal
  };



  const angel_payloads = {
    login_id: brokerid,
    nick_name: user_name,
    broker: broker,
    twofa: twofa,
    mpin: mpin,
    app_id: apikey,
    phone_num: phonenumber,
    no_of_lots: lotsize,
  };

  const iifl_payloads = {
    login_id: brokerid,
    nick_name: user_name,
    broker: broker,
    app_id: apikey,
    api_secret: apisecret,
    phone_num: phonenumber,
    no_of_lots: lotsize,
  };

  const showAlert = (title, text, icon) => {
    Swal.fire({
      title: title,
      text: text,
      icon: icon,
      toast: true,
      position: "top-end",
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      customClass: {
        popup: "custom-toast",
        container: "no-overlay",
      },
    });
  };

  const removeData = () => {
    setBrokerid('');
    setuser_name('');
    setBroker('');
    setTwofa('');
    setMpin('');
    setApikey('');
    setApiSecret('');
    setPhonenumber('');
    setlotsize('');
  };


  const submitBrokerDetails = async (e) => {
    e.preventDefault();
    try {
      const brokerRequiredFields = broker === "iifl"
        ? [broker, brokerid, apikey, apisecret, phonenumber, lotsize]
        : [broker, brokerid, twofa, mpin, apikey, phonenumber, lotsize];

      const isFieldsValid = brokerRequiredFields.every((field) => !!field);

      if (!isFieldsValid) {
        showAlert("Warning!", "All required fields must be provided.", "warning");
        return;
      }

      const payload = broker === "iifl" ? iifl_payloads : angel_payloads;

      const res = await axios.post(
        `${process.env.REACT_APP_API_URL_INTERACTIVE}user-broker-details/filterbyuser/`,
        payload,
        {
          headers: {
            Authorization: `Token ${token}`,
          },
        }
      );

      const statusCode = res.data.statuscode;

      if (statusCode === 201) {
        console.log(res.data.message);
        fetchuserDetails()
        showAlert("Success!", res.data.message, "success");
        removeData()
      } else {
        showAlert("Error!", "Something went wrong. Please try again later.", "error");
      }
    } catch (error) {
      console.error("Error submitting broker details:", error);
      showAlert("Error!", "Error submitting broker details.", "error");
    }
  };


  const editBrokerDetails = async (e) => {
    e.preventDefault();
    try {
      const brokerRequiredFields = broker === "iifl"
        ? [broker, brokerid, apikey, apisecret, phonenumber, lotsize]
        : [broker, brokerid, twofa, mpin, apikey, phonenumber, lotsize];

      const isFieldsValid = brokerRequiredFields.every((field) => !!field);

      if (!isFieldsValid) {
        showAlert("Warning!", "All required fields must be provided.", "warning");
        return;
      }

      const payload = broker === "iifl" ? iifl_payloads : angel_payloads;

      const res = await axios.put(
        `${process.env.REACT_APP_API_URL_INTERACTIVE}user-broker-details/filterbyuser/${user_id}`,
        payload,
        {
          headers: {
            Authorization: `Token ${token}`,
          },
        }
      );

      const statusCode = res.data.statuscode;

      if (statusCode === 201) {
        console.log(res.data.message);
        fetchuserDetails()
        showAlert("Success!", res.data.message, "success");
        removeData()
      } else {
        showAlert("Error!", "Something went wrong. Please try again later.", "error");
      }
    } catch (error) {
      console.error("Error submitting broker details:", error);
      showAlert("Error!", "Error submitting broker details.", "error");
    }
  };

  const deleteBrokerdetails = async (id) => {
    console.log(id)
    if (id) {
      try {
        const res = await axios.delete(
          `${process.env.REACT_APP_API_URL_INTERACTIVE}user-broker-details/filterbyuser/${id}/`,
          {
            headers: {
              Authorization: `Token ${token}`,
            },
          }
        );

        const statusCode = res.data.statuscode;

        if (statusCode === 200) {
          console.log(res.data.message);
          fetchuserDetails()
          showAlert("Success!", res.data.message, "success");
          removeData()
        } else {
          showAlert("Error!", "Something went wrong. Please try again later.", "error");
        }
      } catch (error) {
        console.error("Error deleting broker details:", error);
        showAlert("Error!", "Error deleting broker details.", "error");
      }
    }
  }

  return (
    <div>
      <div className='multi-users'>
        <div className='heading'>
          <h4>Multi Users</h4>
        </div>
        <div className='add-user-button'>
          <button data-bs-toggle="modal" data-bs-target="#staticBackdropgroup">Add New Group</button>
          <button data-bs-toggle="modal" data-bs-target="#staticBackdrop">Add New User</button>
        </div>
      </div>

      <div className="table-container">
        <div className="table-header">
          <div className="search-wrapper">
            <input
              type="text"
              id="search-input"
              placeholder="Search by User"
              value={searchTerm}
              onChange={handleSearch} // Correct way to pass the function reference
            />

            <i className="fas fa-search"></i>
          </div>
        </div>
        <div className="table-responsive">
          <table className="position-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Broker Name</th>
                <th>Broker Id</th>
                <th>Lot size</th>
                <th>Api_id</th>
                <th>Api Secret</th>
                <th>Phone number</th>
                <th></th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((position, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{position.nick_name}</td>
                  <td>{position.broker}</td>
                  <td>{position.login_id}</td>
                  <td>{position.no_of_slots}</td>
                  <td>{position.app_id}</td>
                  <td>{position.api_secret}</td>
                  <td>{position.phone_num}</td>
                  <td>
                    <button
                      className="badge-dark-modify"
                      onClick={() => handleModify(position)} // Pass the position to handleModify
                    >
                      Edit
                    </button>
                  </td>
                  <td>
                    <button className="badge-danger-sqroff" onClick={() => deleteBrokerdetails(position.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <div className="view-options">
            <select
              id="rows-select"
              value={itemsPerPage}
              onChange={handleRowsChange}
            >
              <option value="10">10</option>
              <option value="20">20</option>
              <option value="50">50</option>
            </select>
          </div>
          <button onClick={handlePrevPage} disabled={currentPage === 1}>
            Previous
          </button>
          <span>
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>
      </div>

      {/* Add new user modal  */}

      <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">User Details</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={removeData}></button>
            </div>
            <div class="modal-body add-user">
              <div className='row'>
                <div className="broker-modal">
                  <form className="form-fields">
                    <div className='row'>
                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <select onChange={(e) => setBroker(e.target.value)} value={broker}>
                            <option value="">Select a broker</option>
                            <option value="iifl">IIFL</option>
                            <option value="angel">ANGEL</option>
                          </select>

                        </div>
                      </div>


                      {/* <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="text"
                            placeholder="Broker user id"
                            value={brokerid}
                            onChange={(e) => setBrokerid(e.target.value)}
                          />
                        </div>
                      </div> */}

                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="text"
                            placeholder="Broker user id"
                            value={brokerid}
                            onChange={(e) => setBrokerid(e.target.value)}
                          />
                        </div>
                      </div>

                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="text"
                            placeholder="Enter Name"
                            value={user_name}
                            onChange={(e) => setuser_name(e.target.value)}
                          />
                        </div>
                      </div>

                      {broker === "angel" ? (
                        <>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Twofa"
                                value={twofa}
                                onChange={(e) => setTwofa(e.target.value)}
                              />
                            </div>
                          </div>

                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Mpin"
                                value={mpin}
                                onChange={(e) => setMpin(e.target.value)}
                              />
                            </div>
                          </div>
                        </>
                      ) : null}
                      {broker === "angel" ? (
                        <>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Api Key"
                                value={apikey}
                                onChange={(e) => setApikey(e.target.value)}
                              />
                            </div>
                          </div>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="number"
                                placeholder="Phone number"
                                value={phonenumber}
                                onChange={(e) => setPhonenumber(e.target.value)}
                              />
                            </div>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Api Key"
                                value={apikey}
                                onChange={(e) => setApikey(e.target.value)}
                              />
                            </div>
                          </div>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Api Secret"
                                value={apisecret}
                                onChange={(e) => setApiSecret(e.target.value)}
                              />
                            </div>
                          </div>

                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="number"
                                placeholder="Phone number"
                                value={phonenumber}
                                onChange={(e) => setPhonenumber(e.target.value)}
                              />
                            </div>
                          </div>
                        </>
                      )}
                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="number"
                            placeholder="Lot Size"
                            value={lotsize}
                            onChange={(e) => setlotsize(e.target.value)}
                          />
                        </div>
                      </div>
                    </div>

                    <div>

                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              {/* <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> */}
              <input
                type="submit"
                onClick={submitBrokerDetails}
                className="btn btn-success add-user-broker-submit "
              />
            </div>
          </div>
        </div>
      </div>

      {/* Edit user  */}

      <button data-bs-toggle="modal" data-bs-target="#staticBackdropedit" ref={buttonRef} hidden></button>

      <div class="modal fade" id="staticBackdropedit" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">Modify User Details</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={removeData}></button>
            </div>
            <div class="modal-body add-user">
              <div className='row'>
                <div className="broker-modal">
                  <form className="form-fields">
                    <div className='row'>
                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <select onChange={(e) => setBroker(e.target.value)} value={broker}>
                            <option value="">Select a broker</option>
                            <option value="iifl">IIFL</option>
                            <option value="angel">ANGEL</option>
                          </select>

                        </div>
                      </div>


                      {/* <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="text"
                            placeholder="Broker user id"
                            value={brokerid}
                            onChange={(e) => setBrokerid(e.target.value)}
                          />
                        </div>
                      </div> */}

                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="text"
                            placeholder="Broker user id"
                            value={brokerid}
                            onChange={(e) => setBrokerid(e.target.value)}
                          />
                        </div>
                      </div>

                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="text"
                            placeholder="Enter Name"
                            value={user_name}
                            onChange={(e) => setuser_name(e.target.value)}
                          />
                        </div>
                      </div>

                      {broker === "angel" ? (
                        <>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Twofa"
                                value={twofa}
                                onChange={(e) => setTwofa(e.target.value)}
                              />
                            </div>
                          </div>

                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Mpin"
                                value={mpin}
                                onChange={(e) => setMpin(e.target.value)}
                              />
                            </div>
                          </div>
                        </>
                      ) : null}
                      {broker === "angel" ? (
                        <>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Api Key"
                                value={apikey}
                                onChange={(e) => setApikey(e.target.value)}
                              />
                            </div>
                          </div>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="number"
                                placeholder="Phone number"
                                value={phonenumber}
                                onChange={(e) => setPhonenumber(e.target.value)}
                              />
                            </div>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Api Key"
                                value={apikey}
                                onChange={(e) => setApikey(e.target.value)}
                              />
                            </div>
                          </div>
                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="text"
                                placeholder="Api Secret"
                                value={apisecret}
                                onChange={(e) => setApiSecret(e.target.value)}
                              />
                            </div>
                          </div>

                          <div className='col-4 mt-2'>
                            <div className='add-user'>
                              <input
                                type="number"
                                placeholder="Phone number"
                                value={phonenumber}
                                onChange={(e) => setPhonenumber(e.target.value)}
                              />
                            </div>
                          </div>
                        </>
                      )}
                      <div className='col-4 mt-2'>
                        <div className='add-user'>
                          <input
                            type="number"
                            placeholder="Lot Size"
                            value={lotsize}
                            onChange={(e) => setlotsize(e.target.value)}
                          />
                        </div>
                      </div>
                    </div>

                    <div>

                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              {/* <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> */}
              <input
                type="submit"
                onClick={editBrokerDetails}
                className="btn btn-success add-user-broker-submit "
              />
            </div>
          </div>
        </div>
      </div>



      <div class="modal fade" id="staticBackdropgroup" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">Add Group</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={removeData}></button>
            </div>
            <div class="modal-body add-user">

                <div className="add-group-modal">
                  <form>
                      <div className=''>
                      <div className=''>
                    <label>Group Name</label>
                    <br></br>
                    <input className='group-input' placeholder='Enter New Group Name'></input>
                    </div>

                    <div className=' add-group-btn'>
                     <div className='mt-3'>
                     <button onClick={editBrokerDetails} className="btn btn-success add-user-broker-submit">
                        Add Group
                        </button>
                     </div>
                    </div>
                      </div>
                  </form>

              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  )
}

export default Multiclient